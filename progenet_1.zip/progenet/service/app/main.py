"""
ProGENET · main.py

FastAPI inference service. Stateless, synchronous, in-process ONNX (ADR-003).
Uploads are held in memory and discarded with the response — nothing touches
disk.
"""

from __future__ import annotations

import base64
import io
import logging
import os
import uuid
from contextlib import asynccontextmanager

import numpy as np
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .inference import MODEL, LowTissueCoverage, ModelNotLoaded, DISCLAIMER
from .preprocessing import spotted_pattern

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s · %(message)s")
log = logging.getLogger("progenet")

MAX_UPLOAD_BYTES = 20 * 1024 * 1024
BUILD_SHA = os.getenv("BUILD_SHA", "dev")


@asynccontextmanager
async def lifespan(app: FastAPI):
    MODEL.load()          # a missing artifact is a 503 on /predict, not a crash
    yield


app = FastAPI(
    title="ProGENET",
    description=("Prostate Gleason Evaluation Network — ordinal ISUP grading "
                 "from biopsy whole-slide images. " + DISCLAIMER),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ── helpers ─────────────────────────────────────────────────────────────── #

async def read_image(file: UploadFile) -> np.ndarray:
    raw = await file.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"file exceeds {MAX_UPLOAD_BYTES // 1_000_000} MB")
    if not raw:
        raise HTTPException(415, "empty upload")

    from PIL import Image

    Image.MAX_IMAGE_PIXELS = None
    try:
        return np.asarray(Image.open(io.BytesIO(raw)).convert("RGB"))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(415, f"could not decode image: {exc}") from exc


def png_b64(arr: np.ndarray, max_edge: int = 512) -> str:
    from PIL import Image

    im = Image.fromarray(arr)
    if max(im.size) > max_edge:
        im.thumbnail((max_edge, max_edge))
    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


# ── routes ──────────────────────────────────────────────────────────────── #

@app.get("/healthz")
def healthz():
    return {"status": "ok", "model_loaded": MODEL.ready}


@app.get("/version")
def version():
    return {
        "service": "progenet",
        "build": BUILD_SHA,
        "model": MODEL.meta.get("name"),
        "model_version": MODEL.meta.get("version"),
        "qwk_val": MODEL.meta.get("qwk_val"),
        "preprocessing_hash": MODEL.preprocessing_hash,
        "preprocessing": MODEL.meta.get("preprocessing", {}),
        "disclaimer": DISCLAIMER,
    }


@app.post("/preprocess")
async def preprocess(file: UploadFile = File(...)):
    """Return the preprocessing stages as images.

    This exists so the UI can show the pipeline rather than only its answer.
    A pathologist deciding whether to trust a grade wants to see which tiles the
    system actually looked at — a black box that emits a number earns less trust
    than one that shows its working, even when the number is identical.
    """
    if not MODEL.ready:
        raise HTTPException(503, "model artifact not loaded")

    img = await read_image(file)
    try:
        _, prov = MODEL.preprocess(img)
    except LowTissueCoverage as exc:
        raise HTTPException(422, str(exc)) from exc

    return {
        "stages": {
            "montage": png_b64(prov["montage_raw"]),
            "normalised": png_b64(prov["montage_processed"]),
            "pattern": png_b64(spotted_pattern(prov["montage_processed"])),
        },
        "tiles": prov["tiles"] | {"coverage": prov["coverage"]},
        "flags": prov["flags"],
    }


@app.post("/predict")
async def predict(
    file: UploadFile = File(...),
    explain: bool = Query(False, description="include preprocessing previews"),
):
    if not MODEL.ready:
        raise HTTPException(503, "model artifact not loaded — see docs/04-runbook.md")

    img = await read_image(file)

    try:
        result, prov = MODEL.predict(img)
    except LowTissueCoverage as exc:
        # Refusing beats guessing. A confident grade on a non-histology image is
        # worse than an error the user can act on.
        raise HTTPException(422, {
            "error": "insufficient_tissue",
            "message": ("Less than 5% of this image is tissue. ProGENET will not "
                        "grade it. Upload a biopsy field or a slide export."),
            "coverage": exc.coverage,
        }) from exc
    except ModelNotLoaded as exc:
        raise HTTPException(503, str(exc)) from exc

    result["request_id"] = uuid.uuid4().hex[:12]

    if explain:
        result["previews"] = {
            "montage": png_b64(prov["montage_raw"]),
            "normalised": png_b64(prov["montage_processed"]),
        }

    log.info("predict %s → ISUP %d (conf %.2f, %d ms, flags=%s)",
             result["request_id"], result["prediction"]["isup_grade"],
             result["prediction"]["confidence"], result["latency_ms"],
             result["flags"] or "-")

    return result


@app.exception_handler(Exception)
async def unhandled(request, exc):  # noqa: ARG001
    log.exception("unhandled error")
    return JSONResponse(status_code=500,
                        content={"error": "internal", "message": str(exc)})
