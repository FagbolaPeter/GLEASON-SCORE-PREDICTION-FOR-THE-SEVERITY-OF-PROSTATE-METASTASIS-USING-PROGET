"""
ProGENET · inference.py

Model loading and the prediction path. ONNXRuntime on CPU, loaded once at
startup and held in process (ADR-003).

The preprocessing here must match the training notebook exactly. It is driven
entirely by `model_meta.json`, which the notebook writes alongside the ONNX
graph — tile count, stain reference, normalisation statistics, thresholds. If
the model changes, the preprocessing changes with it, automatically. Hard-coding
any of it here is how train/serve skew gets introduced.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Any

import numpy as np

from .preprocessing import macenko, gaussian_denoise, tissue_coverage, montage_from_image

log = logging.getLogger("progenet.inference")

ARTIFACT_DIR = Path(__file__).resolve().parent.parent / "artifacts"

ISUP_TO_GLEASON = {0: "0+0", 1: "3+3", 2: "3+4", 3: "4+3", 4: "4+4", 5: "4+5"}
RISK_BAND = {
    0: "benign / no carcinoma",
    1: "low risk",
    2: "intermediate — favourable",
    3: "intermediate — unfavourable",
    4: "high risk",
    5: "very high risk",
}
DISCLAIMER = ("Research use only. Not a medical device. "
              "Not for clinical decision-making.")


class ModelNotLoaded(RuntimeError):
    pass


class LowTissueCoverage(ValueError):
    """Raised when the upload has too little tissue to grade honestly.

    Refusing is the right behaviour here. A confident grade on a photograph of a
    desk is worse than an error message.
    """
    def __init__(self, coverage: float):
        self.coverage = coverage
        super().__init__(f"tissue coverage {coverage:.3f} below 0.05 floor")


class ProGENETModel:
    """Wraps the ONNX session, the ordinal decode, and the preprocessing config."""

    def __init__(self, artifact_dir: Path = ARTIFACT_DIR):
        self.artifact_dir = Path(artifact_dir)
        self.session = None
        self.meta: dict[str, Any] = {}
        self.thresholds = np.array([0.5] * 5)
        self.preprocessing_hash = "unloaded"
        self._input_name = "montage"

    # ── lifecycle ────────────────────────────────────────────────────────── #

    def load(self) -> bool:
        meta_path = self.artifact_dir / "model_meta.json"
        onnx_paths = sorted(self.artifact_dir.glob("*.onnx"))

        if not meta_path.exists() or not onnx_paths:
            log.warning("No artifacts in %s — service will answer 503 on /predict. "
                        "Train with notebooks/progenet-panda-training.ipynb and "
                        "drop the ONNX + model_meta.json here.", self.artifact_dir)
            return False

        self.meta = json.loads(meta_path.read_text())
        self.thresholds = np.asarray(self.meta.get("thresholds", [0.5] * 5))

        # The preprocessing config is part of the model's identity. Hash it so
        # /version can prove which one produced a given prediction.
        pp = json.dumps(self.meta.get("preprocessing", {}), sort_keys=True)
        self.preprocessing_hash = hashlib.sha256(pp.encode()).hexdigest()[:12]

        import onnxruntime as ort

        opts = ort.SessionOptions()
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        opts.intra_op_num_threads = 2          # matches the 2-vCPU serving target

        t0 = time.time()
        self.session = ort.InferenceSession(
            str(onnx_paths[0]), opts, providers=["CPUExecutionProvider"]
        )
        self._input_name = self.session.get_inputs()[0].name

        log.info("Loaded %s (%s) in %.1fs · QWK %.4f · preprocessing %s",
                 onnx_paths[0].name, self.meta.get("version", "?"),
                 time.time() - t0, self.meta.get("qwk_val", float("nan")),
                 self.preprocessing_hash)
        return True

    @property
    def ready(self) -> bool:
        return self.session is not None

    # ── prediction ───────────────────────────────────────────────────────── #

    def _pp(self, key: str, default):
        return self.meta.get("preprocessing", {}).get(key, default)

    def preprocess(self, image: np.ndarray) -> tuple[np.ndarray, dict]:
        """Upload → model-ready tensor. Returns (tensor, provenance)."""
        flags: list[str] = []

        montage, tile_stats = montage_from_image(
            image,
            n_tiles=self._pp("n_tiles", 36),
            tile_size=self._pp("tile_size", 256),
            out_size=self._pp("img_size", 512),
        )
        raw_montage = montage.copy()

        if self._pp("stain_norm", True):
            ref = np.asarray(self._pp("stain_reference", None) or
                             [[0.5626, 0.2159], [0.7201, 0.8012], [0.4062, 0.5581]])
            conc = np.asarray(self._pp("stain_max_conc", None) or [1.9705, 1.0308])
            montage, ok = macenko(montage, ref, conc)
            if not ok:
                flags.append("STAIN_NORM_FAILED")

        sigma = float(self._pp("gaussian_sigma", 0.0))
        if sigma > 0:
            montage = gaussian_denoise(montage, sigma)

        if self._pp("to_grayscale", False):
            g = montage.mean(-1).astype(np.uint8)
            montage = np.stack([g, g, g], -1)

        cov = tissue_coverage(montage)
        if cov < 0.05:
            raise LowTissueCoverage(cov)
        if cov < 0.15:
            flags.append("LOW_TISSUE_COVERAGE")
        if tile_stats["tissue_bearing"] < tile_stats["requested"] * 0.4:
            flags.append("SPARSE_TILES")

        mean = np.asarray(self._pp("normalize_mean", [0.485, 0.456, 0.406]))
        std = np.asarray(self._pp("normalize_std", [0.229, 0.224, 0.225]))
        x = montage.astype(np.float32) / 255.0
        x = (x - mean) / std
        tensor = x.transpose(2, 0, 1)[None].astype(np.float32)

        return tensor, {
            "flags": flags,
            "coverage": round(float(cov), 4),
            "tiles": tile_stats,
            "montage_raw": raw_montage,
            "montage_processed": montage,
        }

    @staticmethod
    def _sigmoid(z: np.ndarray) -> np.ndarray:
        return 1.0 / (1.0 + np.exp(-z))

    def _distribution(self, ordinal_p: np.ndarray) -> np.ndarray:
        """Cumulative probabilities → 6-class distribution.

        P(g=k) = P(≥k) − P(≥k+1). Clipped at zero because the cumulative
        probabilities are encouraged but not guaranteed monotone (ADR-002),
        then renormalised. Not calibrated — a ranking of belief, not a
        probability to bet on.
        """
        cum = np.concatenate([[1.0], ordinal_p, [0.0]])
        d = np.clip(cum[:-1] - cum[1:], 0, None)
        return d / max(d.sum(), 1e-9)

    def predict(self, image: np.ndarray) -> dict:
        if not self.ready:
            raise ModelNotLoaded("no model artifact loaded")

        t0 = time.time()
        tensor, prov = self.preprocess(image)

        logits = self.session.run(None, {self._input_name: tensor})[0][0]
        ordinal_p = self._sigmoid(logits)

        grade = int((ordinal_p > self.thresholds).sum())
        dist = self._distribution(ordinal_p)

        # Non-monotone cumulative outputs are a training-health signal, not a
        # user error — but they do mean the distribution is less trustworthy.
        if np.any(np.diff(ordinal_p) > 0.05):
            prov["flags"].append("NON_MONOTONE_ORDINAL")

        return {
            "model": {
                "name": self.meta.get("name", "progenet"),
                "version": self.meta.get("version", "0.0.0"),
                "qwk_val": self.meta.get("qwk_val"),
                "preprocessing_hash": self.preprocessing_hash,
            },
            "prediction": {
                "isup_grade": grade,
                "gleason_score": ISUP_TO_GLEASON[grade],
                "risk_band": RISK_BAND[grade],
                "confidence": round(float(dist[grade]), 4),
            },
            "distribution": {str(i): round(float(p), 4) for i, p in enumerate(dist)},
            "ordinal_probs": [round(float(p), 4) for p in ordinal_p],
            "ordinal_logits": [round(float(z), 4) for z in logits],
            "tiles": prov["tiles"] | {"coverage": prov["coverage"]},
            "flags": prov["flags"],
            "latency_ms": int((time.time() - t0) * 1000),
            "disclaimer": DISCLAIMER,
        }, prov


MODEL = ProGENETModel()
