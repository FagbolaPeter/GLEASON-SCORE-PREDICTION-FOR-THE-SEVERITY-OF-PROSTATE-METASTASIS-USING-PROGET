"""
ProGENET · preprocessing.py

Serving-side copy of the tiling and stain-normalisation used in training.
Kept dependency-light on purpose: numpy and Pillow only, so the inference
container does not need openslide, scipy or scikit-image.

The algorithms are identical to `pipeline/bin/tile_wsi.py` and
`pipeline/bin/preprocess_tiles.py`. `tests/test_parity.py` asserts that on the
same input all three paths agree — which is the only thing that keeps this
duplication honest.
"""

from __future__ import annotations

import numpy as np

BACKGROUND_THRESH = 235
MIN_TISSUE_PIXELS = 512

REF_STAIN_MATRIX = np.array([[0.5626, 0.2159],
                             [0.7201, 0.8012],
                             [0.4062, 0.5581]])
REF_MAX_CONC = np.array([1.9705, 1.0308])


# ── tiling ──────────────────────────────────────────────────────────────── #

def pad_to_multiple(img: np.ndarray, tile: int) -> np.ndarray:
    h, w = img.shape[:2]
    ph, pw = (-h) % tile, (-w) % tile
    if not (ph or pw):
        return img
    return np.pad(img, [(ph // 2, ph - ph // 2), (pw // 2, pw - pw // 2), (0, 0)],
                  constant_values=255)


def cut_tiles(img: np.ndarray, tile: int) -> np.ndarray:
    img = pad_to_multiple(img, tile)
    r, c = img.shape[0] // tile, img.shape[1] // tile
    return (img.reshape(r, tile, c, tile, 3)
               .transpose(0, 2, 1, 3, 4)
               .reshape(-1, tile, tile, 3))


def select_tiles(tiles: np.ndarray, n: int) -> tuple[np.ndarray, np.ndarray]:
    scores = (255 - tiles.reshape(len(tiles), -1).astype(np.int64)).sum(1)
    keep = np.argsort(-scores)[:n]
    out, sc = tiles[keep], scores[keep]
    if len(out) < n:
        short = n - len(out)
        out = np.concatenate([out, np.full((short, *tiles.shape[1:]), 255, np.uint8)])
        sc = np.concatenate([sc, np.zeros(short, np.int64)])
    return out, sc


def build_montage(tiles: np.ndarray) -> np.ndarray:
    n = len(tiles)
    s = int(round(n ** 0.5))
    if s * s != n:
        raise ValueError(f"n_tiles must be a perfect square, got {n}")
    t = tiles.shape[1]
    return (tiles.reshape(s, s, t, t, 3)
                 .transpose(0, 2, 1, 3, 4)
                 .reshape(s * t, s * t, 3))


def montage_from_image(img: np.ndarray, n_tiles: int = 36, tile_size: int = 256,
                       out_size: int = 512) -> tuple[np.ndarray, dict]:
    """Upload → montage. Handles both large slide exports and small crops.

    A user may upload a 5000px slide export or a 600px photographed field. Both
    must work. If the image is smaller than the tile grid needs, it is upscaled
    first rather than being padded into a montage of mostly white — padding a
    small field would collapse its tissue coverage and trigger a spurious
    refusal.
    """
    from PIL import Image

    need = tile_size * int(round(n_tiles ** 0.5))
    h, w = img.shape[:2]
    if min(h, w) < need // 2:
        scale = (need // 2) / min(h, w)
        img = np.asarray(Image.fromarray(img).resize(
            (int(w * scale), int(h * scale)), Image.BILINEAR))

    tiles, scores = select_tiles(cut_tiles(img, tile_size), n_tiles)
    montage = build_montage(tiles)

    if montage.shape[0] != out_size:
        montage = np.asarray(Image.fromarray(montage).resize(
            (out_size, out_size), Image.BILINEAR))

    return montage, {
        "requested": n_tiles,
        "tissue_bearing": int((scores > 0).sum()),
        "grid": [int(round(n_tiles ** 0.5))] * 2,
    }


# ── stain normalisation ─────────────────────────────────────────────────── #

def macenko(img: np.ndarray,
            ref_stain: np.ndarray = REF_STAIN_MATRIX,
            ref_conc: np.ndarray = REF_MAX_CONC,
            io: int = 240, beta: float = 0.15,
            alpha: float = 1.0) -> tuple[np.ndarray, bool]:
    """Macenko (2009). Returns (image, ok); never raises — see ADR-004."""
    h, w = img.shape[:2]
    od = -np.log(np.maximum(img.reshape(-1, 3).astype(np.float64), 1) / io)
    od_hat = od[np.linalg.norm(od, axis=1) > beta]
    if len(od_hat) < MIN_TISSUE_PIXELS:
        return img, False

    try:
        _, eigvecs = np.linalg.eigh(np.cov(od_hat.T))
        plane = eigvecs[:, 1:3]
        proj = od_hat @ plane
        ang = np.arctan2(proj[:, 1], proj[:, 0])
        lo, hi = np.percentile(ang, [alpha, 100 - alpha])

        v1 = plane @ np.array([np.cos(lo), np.sin(lo)])
        v2 = plane @ np.array([np.cos(hi), np.sin(hi)])
        he = np.array([v1, v2]).T if v1[0] > v2[0] else np.array([v2, v1]).T
        he = he / np.linalg.norm(he, axis=0, keepdims=True)

        conc = np.linalg.lstsq(he, od.T, rcond=None)[0]
        mx = np.percentile(conc, 99, axis=1)
        mx[mx < 1e-6] = 1e-6
        conc *= (np.asarray(ref_conc) / mx)[:, None]

        out = np.clip((io * np.exp(-np.asarray(ref_stain) @ conc)).T.reshape(h, w, 3),
                      0, 255)
        return out.astype(np.uint8), True
    except (np.linalg.LinAlgError, ValueError):
        return img, False


def gaussian_denoise(img: np.ndarray, sigma: float) -> np.ndarray:
    """Separable Gaussian blur in pure numpy — no scipy in the serving image."""
    if sigma <= 0:
        return img
    radius = max(1, int(3 * sigma))
    x = np.arange(-radius, radius + 1)
    k = np.exp(-(x ** 2) / (2 * sigma ** 2))
    k /= k.sum()

    out = img.astype(np.float32)
    pad = np.pad(out, [(0, 0), (radius, radius), (0, 0)], mode="edge")
    out = np.stack([np.convolve(pad[i, :, c], k, "valid")
                    for i in range(out.shape[0]) for c in range(3)], 0)
    out = out.reshape(img.shape[0], 3, -1).transpose(0, 2, 1)

    pad = np.pad(out, [(radius, radius), (0, 0), (0, 0)], mode="edge")
    out = np.stack([np.convolve(pad[:, j, c], k, "valid")
                    for j in range(out.shape[1]) for c in range(3)], 0)
    out = out.reshape(img.shape[1], 3, -1).transpose(2, 0, 1)

    return np.clip(out, 0, 255).astype(np.uint8)


def tissue_coverage(img: np.ndarray, thresh: int = BACKGROUND_THRESH) -> float:
    return float((img.mean(-1) < thresh).mean())


def spotted_pattern(img: np.ndarray, percentile: float = 12.0) -> np.ndarray:
    """The 2021 'spotted pattern' view — darkest pixels marked, which reads as
    nuclear density. A display aid for the UI, never a model input."""
    gray = img.mean(-1)
    out = img.copy()
    out[gray < np.percentile(gray, percentile)] = 0
    return out
