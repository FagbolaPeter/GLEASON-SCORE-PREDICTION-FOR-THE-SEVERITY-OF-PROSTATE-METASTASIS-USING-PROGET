"""
Parity tests: the serving preprocessing must match the pipeline's, exactly.

There are two copies of the tiling and stain-normalisation code — one in
`pipeline/bin/` (openslide, scipy, scikit-image, for bulk offline work) and one
in `service/app/preprocessing.py` (numpy + Pillow only, so the container stays
small). Duplication is a deliberate trade, and these tests are the price of it:
if the two ever drift, a model validated on one preprocessing gets served with
another, and the validation number stops meaning anything.

    pytest service/tests -q
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "service"))
sys.path.insert(0, str(ROOT / "pipeline" / "bin"))

from app import preprocessing as svc          # noqa: E402


@pytest.fixture
def fake_slide() -> np.ndarray:
    """A synthetic H&E-ish slide: white background, a diagonal tissue strip."""
    rng = np.random.default_rng(0)
    img = np.full((1536, 1536, 3), 250, np.uint8)
    for i in range(1536):
        lo, hi = max(0, i - 180), min(1536, i + 180)
        band = rng.normal([170, 110, 180], 22, (hi - lo, 3))
        img[i, lo:hi] = np.clip(band, 0, 255).astype(np.uint8)
    return img


# ── tiling ──────────────────────────────────────────────────────────────── #

def test_montage_shape_and_determinism(fake_slide):
    a, sa = svc.montage_from_image(fake_slide, n_tiles=36, tile_size=256, out_size=512)
    b, sb = svc.montage_from_image(fake_slide, n_tiles=36, tile_size=256, out_size=512)

    assert a.shape == (512, 512, 3)
    assert sa == sb
    np.testing.assert_array_equal(a, b), "tiling must be deterministic (ADR-001)"


def test_tile_selection_prefers_tissue(fake_slide):
    tiles = svc.cut_tiles(fake_slide, 256)
    kept, scores = svc.select_tiles(tiles, 16)
    assert (np.diff(scores) <= 0).all(), "tiles must be ranked by descending tissue"
    assert scores[0] > scores[-1]


def test_white_padding_never_outranks_tissue():
    """A near-empty slide must pad with white, and padding must score zero —
    otherwise a blank tile could displace a real one."""
    sparse = np.full((512, 512, 3), 252, np.uint8)
    sparse[100:150, 100:150] = 90
    _, scores = svc.select_tiles(svc.cut_tiles(sparse, 256), 36)
    assert scores[0] > 0
    assert scores[-1] == 0


def test_non_square_tile_count_rejected():
    with pytest.raises(ValueError, match="perfect square"):
        svc.build_montage(np.zeros((35, 64, 64, 3), np.uint8))


# ── stain normalisation ─────────────────────────────────────────────────── #

def test_macenko_runs_and_preserves_shape(fake_slide):
    out, ok = svc.macenko(fake_slide)
    assert ok
    assert out.shape == fake_slide.shape
    assert out.dtype == np.uint8


def test_macenko_degrades_gracefully_on_blank():
    """Too few tissue pixels → identity + ok=False, never an exception.
    One bad tile must not fail a whole slide (ADR-004)."""
    blank = np.full((256, 256, 3), 255, np.uint8)
    out, ok = svc.macenko(blank)
    assert not ok
    np.testing.assert_array_equal(out, blank)


def test_macenko_reduces_between_slide_colour_variance(fake_slide):
    """The whole point: two slides with different colour casts should land
    closer together after normalisation."""
    warm = np.clip(fake_slide.astype(np.int16) + [22, -8, -14], 0, 255).astype(np.uint8)
    cool = np.clip(fake_slide.astype(np.int16) + [-14, -6, 26], 0, 255).astype(np.uint8)

    before = np.abs(warm.mean((0, 1)) - cool.mean((0, 1))).sum()
    nw, ok_w = svc.macenko(warm)
    nc, ok_c = svc.macenko(cool)
    assert ok_w and ok_c
    after = np.abs(nw.mean((0, 1)) - nc.mean((0, 1))).sum()

    assert after < before, f"colour gap grew: {before:.1f} → {after:.1f}"


# ── misc ────────────────────────────────────────────────────────────────── #

def test_coverage_bounds(fake_slide):
    assert 0.0 < svc.tissue_coverage(fake_slide) < 1.0
    assert svc.tissue_coverage(np.full((64, 64, 3), 255, np.uint8)) == 0.0


def test_gaussian_denoise_is_identity_at_zero(fake_slide):
    np.testing.assert_array_equal(svc.gaussian_denoise(fake_slide, 0.0), fake_slide)


def test_gaussian_denoise_reduces_variance(fake_slide):
    blurred = svc.gaussian_denoise(fake_slide, 1.5)
    assert blurred.shape == fake_slide.shape
    assert blurred.std() < fake_slide.std()


def test_pipeline_and_service_tiling_agree(fake_slide):
    """The parity assertion this file exists for."""
    pipeline = pytest.importorskip("tile_wsi")

    tiles_p, idx_p = pipeline.cut_tiles(fake_slide, 256)
    kept_p, _, _ = pipeline.select_tiles(tiles_p, idx_p, 36)
    montage_p = pipeline.build_montage(kept_p)

    kept_s, _ = svc.select_tiles(svc.cut_tiles(fake_slide, 256), 36)
    montage_s = svc.build_montage(kept_s)

    np.testing.assert_array_equal(montage_p, montage_s)


# ── ordinal decode ──────────────────────────────────────────────────────── #

@pytest.mark.parametrize("probs,expected", [
    ([0.1, 0.1, 0.1, 0.1, 0.1], 0),
    ([0.9, 0.1, 0.1, 0.1, 0.1], 1),
    ([0.9, 0.9, 0.8, 0.1, 0.1], 3),
    ([0.9, 0.9, 0.9, 0.9, 0.9], 5),
])
def test_ordinal_decode(probs, expected):
    assert int((np.array(probs) > 0.5).sum()) == expected


def test_distribution_sums_to_one():
    from app.inference import ProGENETModel

    m = ProGENETModel()
    for p in ([0.9, 0.7, 0.3, 0.1, 0.02], [0.5] * 5, [0.99] * 5):
        d = m._distribution(np.array(p))
        assert len(d) == 6
        assert abs(d.sum() - 1.0) < 1e-6
        assert (d >= 0).all()


def test_distribution_handles_non_monotone_input():
    """Monotonicity is encouraged by the target encoding, not enforced by the
    architecture (ADR-002). A non-monotone row must still yield a valid
    distribution rather than negative probabilities."""
    from app.inference import ProGENETModel

    d = ProGENETModel()._distribution(np.array([0.9, 0.3, 0.7, 0.2, 0.1]))
    assert (d >= 0).all()
    assert abs(d.sum() - 1.0) < 1e-6
