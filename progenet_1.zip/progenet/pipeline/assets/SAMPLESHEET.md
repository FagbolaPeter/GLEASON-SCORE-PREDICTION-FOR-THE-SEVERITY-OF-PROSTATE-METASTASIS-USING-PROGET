# Samplesheet contract

`--input` takes a CSV with a header row and these columns:

| Column | Required | Type | Notes |
|---|---|---|---|
| `image_id` | yes | string | Must match `<slide_dir>/<image_id>.tiff`. PANDA's 32-char hex id. |
| `data_provider` | no | `radboud` \| `karolinska` | Used for provider-stratified validation and the cross-provider shift probe. Defaults to `unknown`. |
| `isup_grade` | no | int 0–5 | Training target. Omit for inference-only runs; defaults to `-1`. |
| `gleason_score` | no | string | e.g. `3+4`, `0+0`, `negative`. Carried through to the manifest for reporting; not a training target (see ADR-002). |

Extra columns are ignored, so PANDA's `train.csv` can be passed straight in:

```bash
nextflow run main.nf -profile docker \
    --input     /data/panda/train.csv \
    --slide_dir /data/panda/train_images \
    --outdir    results
```

Slides listed in the samplesheet but missing from `--slide_dir` are warned about
and skipped rather than failing the run — PANDA ships a handful of known-corrupt
slides, and one bad file should not cost you a six-hour preprocessing job.

## Outputs

```
results/
├── shards/
│   ├── shard_0005f7aa.npy              # (N, 512, 512, 3) uint8
│   └── shard_0005f7aa_manifest.parquet # image_id, provider, isup_grade,
│                                       # gleason_score, coverage, shard_index, sha256
├── qc/
│   ├── progenet_qc.html                # grade + provider + coverage report
│   └── progenet_qc.json
└── pipeline_info/
    ├── report_*.html  timeline_*.html  trace_*.txt  dag_*.html
    └── software_versions.yml
```
