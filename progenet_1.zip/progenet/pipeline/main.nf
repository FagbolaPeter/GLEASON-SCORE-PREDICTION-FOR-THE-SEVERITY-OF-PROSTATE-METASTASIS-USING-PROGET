#!/usr/bin/env nextflow
/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ProGENET  ·  PANDA whole-slide preprocessing pipeline
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Turns raw PANDA whole-slide images into training-ready tile montages.

      TILE_EXTRACT  ─▶  STAIN_NORMALISE  ─▶  PACK_SHARDS  ─▶  QC_REPORT
                                                │
                                         MANIFEST (parquet)

    Written in nf-core house style. Note that nf-core has no whole-slide-image
    pipeline — its catalogue is sequencing-oriented (rnaseq / sarek / atacseq) —
    so this is a purpose-built DSL2 workflow that borrows nf-core's conventions:
    versioned modules, a samplesheet contract, `-profile test`, and per-process
    resource labels.

    Github : https://github.com/<you>/progenet
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

nextflow.enable.dsl = 2

include { TILE_EXTRACT    } from './modules/local/tile_extract'
include { STAIN_NORMALISE } from './modules/local/stain_normalise'
include { PACK_SHARDS     } from './modules/local/pack_shards'
include { QC_REPORT       } from './modules/local/qc_report'

/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    HELP / VALIDATION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

def helpMessage() {
    log.info """
    ProGENET preprocessing  v${workflow.manifest.version}

    Usage:
      nextflow run main.nf -profile docker \\
          --input      samplesheet.csv \\
          --slide_dir  /data/panda/train_images \\
          --outdir     results

    Required:
      --input        Samplesheet CSV: image_id,data_provider,isup_grade,gleason_score
      --slide_dir    Directory holding <image_id>.tiff
      --outdir       Output directory

    Tiling:
      --tile_size    Tile edge in px at the chosen level   [default: ${params.tile_size}]
      --num_tiles    Tiles kept per slide (perfect square) [default: ${params.num_tiles}]
      --level        WSI pyramid level to read             [default: ${params.level}]
      --montage_size Final montage edge in px              [default: ${params.montage_size}]
      --min_coverage Reject slides below this tissue frac  [default: ${params.min_coverage}]

    Preprocessing:
      --stain_norm   Apply Macenko normalisation           [default: ${params.stain_norm}]
      --stain_ref    Reference image for Macenko           [default: bundled]
      --gaussian_sigma  Light denoise sigma, 0 = off       [default: ${params.gaussian_sigma}]
      --to_grayscale    Legacy 2021 mode (see ADR-004)     [default: ${params.to_grayscale}]

    Sharding:
      --shard_size   Slides per .npy shard                 [default: ${params.shard_size}]

    Profiles: docker | singularity | conda | test
    """.stripIndent()
}

if (params.help) { helpMessage(); exit 0 }

if (!params.input)     { exit 1, "ERROR: --input samplesheet not specified" }
if (!params.slide_dir) { exit 1, "ERROR: --slide_dir not specified" }

def n = params.num_tiles as int
if (Math.sqrt(n) != Math.floor(Math.sqrt(n))) {
    exit 1, "ERROR: --num_tiles must be a perfect square (16, 36, 64). Got ${n}. See ADR-001."
}

/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    SAMPLESHEET → CHANNEL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

def parseSamplesheet(path) {
    Channel
        .fromPath(path, checkIfExists: true)
        .splitCsv(header: true, strip: true)
        .map { row ->
            if (!row.image_id) {
                exit 1, "ERROR: samplesheet row missing 'image_id': ${row}"
            }
            def slide = file("${params.slide_dir}/${row.image_id}.tiff")
            if (!slide.exists()) {
                log.warn "Slide not found, skipping: ${slide}"
                return null
            }
            def meta = [
                id           : row.image_id,
                provider     : row.data_provider ?: 'unknown',
                isup_grade   : (row.isup_grade   ?: '-1') as Integer,
                gleason_score: row.gleason_score ?: 'unknown'
            ]
            tuple(meta, slide)
        }
        .filter { it != null }
}

/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    WORKFLOW
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

workflow PROGENET_PREPROCESS {

    take:
    ch_slides    // [ meta, slide.tiff ]

    main:
    ch_versions = Channel.empty()

    //
    // MODULE: tile the slide, score tiles by tissue mass, keep top-N, build montage
    //
    TILE_EXTRACT ( ch_slides )
    ch_versions = ch_versions.mix( TILE_EXTRACT.out.versions.first() )

    //
    // MODULE: Macenko stain normalisation (+ optional Gaussian / legacy grayscale)
    //
    ch_stain_ref = params.stain_ref
        ? Channel.value( file(params.stain_ref, checkIfExists: true) )
        : Channel.value( file("${projectDir}/assets/stain_reference.png") )

    STAIN_NORMALISE ( TILE_EXTRACT.out.montage, ch_stain_ref )
    ch_versions = ch_versions.mix( STAIN_NORMALISE.out.versions.first() )

    //
    // Drop slides whose tissue coverage is too low to grade honestly.
    // Rejected slides are collected and reported, never silently dropped.
    //
    STAIN_NORMALISE.out.montage
        .branch { meta, png, stats ->
            def cov = stats.text.split(',')[0] as Double
            pass: cov >= (params.min_coverage as Double)
                return tuple(meta + [coverage: cov], png)
            fail: true
                return tuple(meta + [coverage: cov], png)
        }
        .set { ch_branched }

    //
    // MODULE: pack montages into .npy shards + a parquet manifest
    //
    ch_branched.pass
        .collate( params.shard_size as int )
        .map { batch ->
            def metas  = batch.collect { it[0] }
            def images = batch.collect { it[1] }
            tuple( [ id: "shard_${metas[0].id.take(8)}", n: batch.size() ], metas, images )
        }
        .set { ch_batches }

    PACK_SHARDS ( ch_batches )
    ch_versions = ch_versions.mix( PACK_SHARDS.out.versions.first() )

    //
    // MODULE: QC — grade distribution, provider balance, coverage histogram, rejects
    //
    QC_REPORT (
        PACK_SHARDS.out.manifest.collect(),
        ch_branched.fail.map { meta, png -> "${meta.id},${meta.provider},${meta.coverage}" }
                        .collectFile( name: 'rejected.csv', newLine: true,
                                      seed: 'image_id,provider,coverage' )
    )

    ch_versions
        .unique()
        .collectFile( name: 'software_versions.yml', storeDir: "${params.outdir}/pipeline_info" )

    emit:
    shards   = PACK_SHARDS.out.shard
    manifest = PACK_SHARDS.out.manifest
    report   = QC_REPORT.out.html
}

workflow {
    PROGENET_PREPROCESS( parseSamplesheet(params.input) )
}

workflow.onComplete {
    log.info """
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      ProGENET preprocessing ${workflow.success ? 'completed successfully' : 'FAILED'}
      Duration : ${workflow.duration}
      Outdir   : ${params.outdir}
      QC report: ${params.outdir}/qc/progenet_qc.html
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    """.stripIndent()
}
