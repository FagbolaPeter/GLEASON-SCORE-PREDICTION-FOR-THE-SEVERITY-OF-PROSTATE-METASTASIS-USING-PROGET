process STAIN_NORMALISE {
    tag   "${meta.id}"
    label 'process_low'

    input:
    tuple val(meta), path(montage)
    path  reference

    output:
    tuple val(meta), path("${meta.id}_norm.png"), path("${meta.id}_cov.txt"), emit: montage
    path "versions.yml"                                                     , emit: versions

    script:
    def norm  = params.stain_norm     ? "--reference ${reference}" : ''
    def sigma = params.gaussian_sigma as Double
    def gauss = sigma > 0             ? "--gaussian-sigma ${sigma}" : ''
    """
    preprocess_tiles.py \\
        --montage  ${montage} \\
        --image-id ${meta.id} \\
        ${norm} \\
        ${gauss}

    cat <<-END_VERSIONS > versions.yml
    "${task.process}":
        scikit-image: \$(python3 -c "import skimage; print(skimage.__version__)")
    END_VERSIONS
    """

    stub:
    """
    touch ${meta.id}_norm.png
    echo "0.42" > ${meta.id}_cov.txt
    touch versions.yml
    """
}
