process TILE_EXTRACT {
    tag   "${meta.id}"
    label 'process_high_memory'

    input:
    tuple val(meta), path(slide)

    output:
    tuple val(meta), path("${meta.id}_montage.png"), emit: montage
    tuple val(meta), path("${meta.id}_tiles.csv")  , emit: tile_stats
    path  "versions.yml"                           , emit: versions

    script:
    def gray = params.to_grayscale ? '--grayscale' : ''
    """
    tile_wsi.py \\
        --slide        ${slide} \\
        --image-id     ${meta.id} \\
        --level        ${params.level} \\
        --tile-size    ${params.tile_size} \\
        --num-tiles    ${params.num_tiles} \\
        --montage-size ${params.montage_size} \\
        ${gray}

    cat <<-END_VERSIONS > versions.yml
    "${task.process}":
        python: \$(python3 --version | sed 's/Python //')
        openslide: \$(python3 -c "import openslide; print(openslide.__version__)")
        numpy: \$(python3 -c "import numpy; print(numpy.__version__)")
    END_VERSIONS
    """

    stub:
    """
    touch ${meta.id}_montage.png
    echo "tile_idx,row,col,tissue_score" > ${meta.id}_tiles.csv
    touch versions.yml
    """
}
