process QC_REPORT {
    label 'process_low'

    publishDir "${params.outdir}/qc", mode: params.publish_dir_mode

    input:
    path manifests
    path rejected

    output:
    path "progenet_qc.html"   , emit: html
    path "progenet_qc.json"   , emit: summary

    script:
    """
    qc_report.py \\
        --manifests ${manifests} \\
        --rejected  ${rejected} \\
        --num-tiles ${params.num_tiles} \\
        --stain-norm ${params.stain_norm} \\
        --gaussian-sigma ${params.gaussian_sigma} \\
        --out progenet_qc
    """

    stub:
    """
    touch progenet_qc.html progenet_qc.json
    """
}
