process PACK_SHARDS {
    tag   "${meta.id}"
    label 'process_medium'

    publishDir "${params.outdir}/shards", mode: params.publish_dir_mode

    input:
    tuple val(meta), val(metas), path(images)

    output:
    tuple val(meta), path("${meta.id}.npy")    , emit: shard
    path "${meta.id}_manifest.parquet"         , emit: manifest
    path "versions.yml"                        , emit: versions

    script:
    // Serialise the per-slide metadata as JSON for the packer.
    def records = groovy.json.JsonOutput.toJson(
        metas.collect { m ->
            [ image_id: m.id, provider: m.provider, isup_grade: m.isup_grade,
              gleason_score: m.gleason_score, coverage: m.coverage ]
        }
    )
    """
    cat > records.json <<'EOF'
    ${records}
    EOF

    pack_shards.py \\
        --records   records.json \\
        --images    ${images} \\
        --shard-id  ${meta.id} \\
        --edge      ${params.montage_size}

    cat <<-END_VERSIONS > versions.yml
    "${task.process}":
        pandas: \$(python3 -c "import pandas; print(pandas.__version__)")
        pyarrow: \$(python3 -c "import pyarrow; print(pyarrow.__version__)")
    END_VERSIONS
    """

    stub:
    """
    touch ${meta.id}.npy ${meta.id}_manifest.parquet versions.yml
    """
}
