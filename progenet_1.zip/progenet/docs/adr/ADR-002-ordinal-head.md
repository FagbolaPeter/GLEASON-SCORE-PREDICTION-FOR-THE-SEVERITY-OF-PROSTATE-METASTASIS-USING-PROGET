# ADR-002 — Cumulative-link ordinal head, optimised against QWK

- **Status:** Accepted
- **Date:** 2026-09-02
- **Supersedes:** the original study's 10-class Gleason-pair softmax with `binary_crossentropy`

## Context

ISUP grade is ordinal, and the clinical cost of an error scales with its
magnitude. Grading a 4+5 case as 4+4 changes little; grading it as 3+3 sends a
patient to active surveillance instead of treatment. The evaluation metric that
encodes this is quadratic weighted kappa, where the penalty on cell (i, j) is
(i − j)² / (N − 1)².

Softmax cross-entropy is blind to this. It assigns the same loss to every wrong
class. A model trained under CE has no gradient signal telling it that ISUP 4 is
a better mistake than ISUP 0 when the truth is 5.

The original study compounded this by training on the 10-way Gleason-pair label
("discrete numbers ranging from 0–9"). That target has two problems: it discards
the ordering entirely, and it asks the model to distinguish 3+4 from 4+3 — which
pattern is *primary* — from a single slide-level label. Its own training logs
show the consequence: QWK oscillating between 0.003 and 0.044, i.e. chance,
while accuracy tables reported 85%. Both numbers are real; only QWK is honest.

## Decision

Train a **5-unit cumulative-link (ordinal-BCE) head** on the 6-class ISUP target,
then fit decision thresholds directly against QWK on the validation fold.

```python
# target encoding: ISUP g → [1]*g + [0]*(5-g)
#   0 → [0,0,0,0,0]      3 → [1,1,1,0,0]
#   1 → [1,0,0,0,0]      4 → [1,1,1,1,0]
#   2 → [1,1,0,0,0]      5 → [1,1,1,1,1]
loss = BCEWithLogitsLoss()(logits, ordinal_target)     # 5 units

# inference
p    = sigmoid(logits)                                  # monotone by construction
grade = (p > tau).sum(axis=1)                           # tau fit by Nelder-Mead on QWK
```

Report Gleason score by inverting the deterministic ISUP ↔ Gleason table rather
than predicting it.

## Rationale

- Unit *k* answers "is the grade at least k+1?" — a question whose difficulty
  increases monotonically, so the head naturally learns an ordered decision
  boundary rather than 6 unrelated ones.
- Errors are penalised by distance: predicting 2 when the truth is 5 gets three
  units wrong, predicting 4 gets one wrong. That is the QWK cost structure,
  expressed in the loss.
- Post-hoc threshold search on QWK is worth 0.01–0.03 kappa at zero training
  cost and is standard practice in the PANDA solutions.
- It is robust to the ±1 label noise that R1 predicts, because an off-by-one label
  only flips one of five units.

There is a pleasing footnote here: the original writeup chose
`binary_crossentropy` for what it called "a multi-class model", which reads as an
error. Cumulative-link ordinal regression *is* BCE on a multi-class problem —
done deliberately, with the right target encoding. The instinct was sound; the
encoding was missing.

## Consequences

**Positive**
- Directly optimises the metric that matters. Expect the largest single QWK gain
  of any change in this rebuild.
- The 5 sigmoid outputs are interpretable on their own ("the model is 91% sure
  this is at least ISUP 1, 68% sure it is at least ISUP 2").
- Confusion matrix errors concentrate on the diagonal's neighbours.

**Negative**
- Monotonicity of `p` is *encouraged* by the target encoding but not *enforced*
  by the architecture. A non-monotone output row (e.g. [0.9, 0.3, 0.7, …]) is
  possible; the `(p > tau).sum()` decision rule tolerates it, but it should be
  monitored as a training-health signal.
- Thresholds are fit on the validation fold and can overfit it on small folds.
  Fit on out-of-fold predictions pooled across folds, not on a single fold.
- The reported per-class `distribution` is a softmax-style transform of the
  ordinal logits and is **not calibrated**. Temperature scaling is deferred
  (see [02-system-design.md §7](../02-system-design.md)).

## Alternatives considered

- **Plain regression + rounding.** Simple, and used by strong PANDA solutions.
  Rejected because it yields no per-class distribution, which the UI needs to
  show uncertainty rather than a bare grade.
- **Softmax CE + QWK-weighted label smoothing.** Approximates ordinality without
  restructuring the head. More hyperparameters, less principled, no interpretable
  intermediate outputs.
