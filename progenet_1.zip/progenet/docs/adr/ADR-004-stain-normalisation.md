# ADR-004 — Keep RGB and stain-normalise; do not convert to grayscale

- **Status:** Accepted
- **Date:** 2026-09-02
- **Supersedes:** the original study's grayscale + Gaussian preprocessing

## Context

The original pipeline resized tiles to 224 × 224, **converted them to
grayscale**, and applied a Gaussian filter for "pattern spotting". The stated
motivation for filtering was noise reduction and edge enhancement; the ablation
(Table 4.1.2a) found Gaussian marginally best among four filters, and a σ sweep
(Table 4.1.2b) found σ = 4 optimal with a collapse from 70.1% to 58.1% by σ = 10.

Two things are worth separating here. The σ sweep is a well-run experiment whose
result — mild blur helps a little, heavy blur destroys the signal — is exactly
what you would expect from a light denoiser. The grayscale conversion, however,
is not a denoising choice, and it is expensive.

Gleason grading is a judgement about glandular architecture in **haematoxylin
and eosin**. H binds nucleic acid and renders nuclei blue-purple; E binds protein
and renders cytoplasm and stroma pink. The distinction between a gland lumen,
its epithelial lining, and the surrounding stroma is carried substantially by
that hue difference. Grayscale projects two chemically distinct channels onto one
intensity axis, and a dense basophilic nucleus and a dense eosinophilic stromal
band can land on the same gray value.

What grayscale *does* buy is invariance to scanner and stain-protocol variation —
and PANDA has exactly that problem, with Radboud and Karolinska slides visibly
differing in colour cast. So the instinct was addressing a real risk (R2). It
just used a blunt instrument.

## Decision

**Keep three-channel RGB. Apply Macenko stain normalisation to a fixed reference
target. Retain Gaussian filtering as an optional light denoise at σ = 1.0,
default off for the production model.**

## Rationale

Macenko (2009) estimates the stain vectors of an H&E image by SVD in optical
density space and re-projects them onto a reference slide's stain matrix. It
removes precisely the between-scanner colour variation that motivated grayscale,
while preserving the H-versus-E separation that grayscale destroys.

Cost is modest: ~80 ms per montage on CPU, inside the latency budget, and it is
applied identically at training and inference so there is no train/serve skew.

The Gaussian filter is demoted rather than deleted. σ = 1.0 is available as a
config flag and ablated in the notebook; the expectation from the original's own
sweep is that its contribution is small once the model has colour information and
a proper ordinal objective to learn from.

## Consequences

**Positive**
- Preserves the diagnostic H&E contrast the task is built on.
- Directly targets risk R2 (cross-provider shift) with the tool designed for it.
- Makes the cross-provider probe in [02-system-design.md §3.5](../02-system-design.md)
  meaningful — with normalisation on, a residual gap is a genuine morphological
  domain shift, not a colour-cast artefact.

**Negative**
- 3× the input channels of grayscale: more memory, marginally slower training.
- Macenko fails on tiles with very little tissue (the SVD is ill-conditioned).
  Handled by falling back to the identity transform when tissue coverage in a
  tile is below threshold, and flagging it.
- Introduces a reference target image as a pipeline artifact that must be
  versioned alongside the model — a normalisation target change silently changes
  the input distribution. It is hashed into `/version`'s preprocessing config
  hash for exactly this reason.

## Alternatives considered

- **Grayscale (original).** Rejected above.
- **Reinhard normalisation.** Cheaper, but operates on global colour statistics
  rather than stain vectors and can distort images whose tissue fraction differs
  from the reference. Macenko is the standard in digital pathology for good
  reason.
- **Heavy colour augmentation, no normalisation.** A defensible alternative that
  several PANDA solutions used successfully: train with aggressive HSV jitter and
  let the model learn invariance. Rejected because it makes inference-time
  behaviour on a *new* scanner unpredictable, whereas normalisation makes it
  explicit. Note that ProGENET applies both — normalisation *and* moderate colour
  jitter during training — since they address the same risk at different points.
