# ADR-003 — Synchronous REST inference, no queue

- **Status:** Accepted
- **Date:** 2026-09-02

## Context

The original study enumerated four deployment patterns (batch/REST,
batch/shared-DB, streaming, on-device) and picked pattern 1. That was correct;
this ADR records *why* it stays correct under ProGENET's constraints, and the
precise conditions under which it stops being correct.

Workload shape: a pathologist opens a case, uploads one image, waits, reads a
grade. It is interactive, low-volume, and bursty within working hours. Load
estimate (see [02-system-design.md §5](../02-system-design.md)): ~1 rps mean,
~5 rps peak for ten mid-sized labs.

## Decision

**One stateless FastAPI container. Synchronous request → response. ONNXRuntime
loaded in-process. No queue, no worker pool, no autoscaler beyond
scale-to-zero.**

## Rationale

At 2.5 s warm inference, a synchronous request is inside the window a human will
wait at a screen without task-switching. Adding a queue would mean adding a job
store, a worker deployment, a polling or websocket channel in the UI, and job
state to reason about — all to serve 1 rps. The complexity has no payer.

Rejecting the alternatives explicitly:

- **Shared-DB batch.** Prediction latency becomes minutes. The whole value
  proposition is a second opinion *while the pathologist is still looking at the
  slide*.
- **Streaming.** Kafka for one image at a time is not a design, it is a costume.
- **On-device.** Attractive for low-bandwidth settings and a genuine future
  option via ONNX-web, but it puts model weights on every client and makes
  versioning and audit impossible in v1.

Statelessness is the load-bearing property. Any replica can serve any request;
there is no session, no sticky routing, and horizontal scaling is `replicas: N`
with no other change.

## Consequences

**Positive**
- Deployable to Cloud Run, Render, Fly, or a Hugging Face Space with no
  infrastructure beyond the container.
- Scale-to-zero: idle cost is zero, which matters for a research deployment with
  no budget.
- Trivially testable — the whole system is `docker run` plus `curl`.

**Negative**
- **Raw whole-slide `.tiff` uploads are out of scope in v1.** Tiling a genuine
  100k-px WSI takes 30–90 s and cannot ride an HTTP request. The API accepts
  slide *images* (a level-1 export, or a photographed/exported field), not raw
  scanner output. This is the sharpest limitation of the design and must be
  stated in the UI, not buried here.
- Cold start on scale-to-zero is ~3–5 s (container + ONNX load). First user of
  the morning waits. Acceptable; a min-instance of 1 removes it for ~$5/month if
  it becomes annoying.
- No retry semantics. A failed request is simply retried by the user.

## Revisit when

| Trigger | Change |
|---|---|
| Raw WSI ingestion is required | Add `202 Accepted` + `GET /jobs/{id}`, a job store, and a worker. This is the one change that genuinely needs a queue. |
| Sustained > 20 rps | `replicas: 4` behind a load balancer. Still no queue. |
| Multi-hospital tenancy | Auth, per-tenant model pinning, append-only audit log. |
