# ADR-001 — Aggregate tiles as a montage, not an attention-MIL bag

- **Status:** Accepted
- **Date:** 2026-09-02
- **Deciders:** ProGENET
- **Supersedes:** the original study's whole-slide-resize approach

## Context

A PANDA slide at level 1 is ~5000 × 5000 px and is 85–95% white space. Any model
that consumes the resized whole slide spends nearly all of its capacity on
background; the original study measured this directly (Table 4.1.1 — tiles 75.8%
test vs. raw 73.4%). So tiling is settled. The open question is how the *set* of
tiles becomes one prediction.

Two credible designs:

**A — Montage.** Select the top N tissue-bearing tiles, arrange them in a √N × √N
grid, feed the composite as a single image. One forward pass.

**B — Attention-MIL.** Embed each tile independently with a shared backbone, pool
the N embeddings with a learned attention head. N forward passes (batched), and
the attention weights are a free, native explanation of which tile drove the
grade.

B is the stronger model — it is what the PANDA competition winner used, and it
does not force the CNN to learn that the seams between tiles are artefacts.

## Decision

**Use the montage (A), at N = 36 in a 6 × 6 grid.**

## Rationale

The binding constraint is N1: end-to-end inference under 8 s on 2 vCPU. Measured
on the target hardware class, EfficientNet-B0:

| | forward passes | CPU latency |
|---|---|---|
| Montage, 512×512 input | 1 | ~1.2 s |
| MIL, 36 × 256×256 tiles | 36 (batched) | ~4–6 s |

MIL fits inside 8 s but consumes most of the budget, leaving no room for tiling,
stain normalisation, and Grad-CAM in the same request. The montage leaves ~5 s of
headroom, which is what makes `/preprocess` previews and explanation affordable
in the same round trip.

The accuracy cost is real but small — PANDA solutions using montage
("tile-concat") landed within ~0.01–0.02 QWK of MIL solutions. Against a project
whose stated impact thesis is *deployability, not accuracy*
([01-problem-framing.md §2](../01-problem-framing.md)), that is the right side of
the trade.

N = 36 is inherited from the original study, which is a convenient continuity;
it is also a perfect square, which the grid requires. It is ablated at 16 / 36 /
64 in the training notebook rather than assumed.

## Consequences

**Positive**
- One forward pass; fits the latency budget with room to spare.
- Grid is axis-aligned, so Grad-CAM over the composite decomposes back to tile
  coordinates exactly — attribution is recovered, just indirectly.
- Simpler training loop; no variable-length batching.

**Negative**
- The CNN must learn to ignore tile seams. Mitigated by consistent tile ordering
  (row-major by descending tissue score) so seams are at fixed positions.
- Fixed N. A slide with 12 tissue tiles gets 24 white tiles padded in; a slide
  with 200 loses information. The `tiles.coverage` field in the API response
  surfaces this to the caller.
- Loses the winner's architecture. If a GPU enters the serving budget, revisit
  this first ([02-system-design.md §7](../02-system-design.md)).

## Alternatives considered

- **Top-1 tile.** Fast, and catastrophically wrong — Gleason grading is explicitly
  about the *distribution* of patterns across the biopsy, not the worst field.
- **Random tile + test-time averaging.** Non-deterministic responses. Unacceptable
  for a clinical decision-support tool where two people must see the same number.
