# ProGENET — System Design

Version 1.0 · Owner: Fagbola Peter · Status: proposed

---

## 1. Requirements

### Functional

| ID | Requirement |
|---|---|
| F1 | Ingest PANDA whole-slide images (`.tiff`, multi-resolution) and their `train.csv` labels. |
| F2 | Deterministically tile each WSI, filter to tissue-bearing tiles, stain-normalise, and pack to training shards. |
| F3 | Train an ordinal grade model and export a portable artifact (ONNX + Keras/PyTorch weights). |
| F4 | Serve `POST /predict` accepting one biopsy image, returning ISUP grade, Gleason pattern, per-class probabilities, and per-tile attribution. |
| F5 | Serve a web interface where a user uploads an image and reads a rendered report. |
| F6 | Every response carries a confidence distribution and an out-of-distribution flag. |

### Non-functional

| ID | Requirement | Target |
|---|---|---|
| N1 | Inference latency, cold path | < 8 s @ 2 vCPU / 4 GB |
| N2 | Inference latency, warm path | < 2.5 s |
| N3 | Model artifact size | < 250 MB |
| N4 | Preprocessing throughput | ≥ 200 slides/hour on 16 cores |
| N5 | Availability | 99% (single region; this is a decision-support tool, not life-support) |
| N6 | Reproducibility | `nextflow run` + pinned container digests → bit-identical shards |
| N7 | Auditability | Every prediction logs model version, preprocessing hash, and input checksum |

### Constraints

- Training compute is a **free Kaggle session**: 1× P100 or T4, 9 h wall clock, 16 GB RAM, 20 GB `/kaggle/working`.
- The dataset (~400 GB) lives on Kaggle and **must not be copied out**.
- Team size: 1–2. Anything requiring a platform team is out of scope.
- No PHI in this system. PANDA is de-identified; the deployed service must not persist uploads.

---

## 2. High-level architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│  OFFLINE  (Kaggle / any Nextflow-capable machine)                       │
│                                                                         │
│   PANDA WSIs ──▶ ┌──────────────────────────────────────────┐          │
│   (.tiff, masks) │  NEXTFLOW PIPELINE  (pipeline/main.nf)   │          │
│   train.csv      │                                          │          │
│                  │  TILE_EXTRACT ─▶ TISSUE_FILTER ─▶        │          │
│                  │  STAIN_NORMALISE ─▶ PACK_SHARDS ─▶ QC    │          │
│                  └──────────────┬───────────────────────────┘          │
│                                 │ .npy shards + manifest.parquet        │
│                                 ▼                                       │
│                  ┌──────────────────────────────────────────┐          │
│                  │  TRAINING  (notebooks/…training.ipynb)   │          │
│                  │  tile-montage ▸ EfficientNet ▸ GeM pool  │          │
│                  │  ▸ ordinal head ▸ QWK threshold search   │          │
│                  └──────────────┬───────────────────────────┘          │
│                                 │ progenet_b0.onnx + thresholds.json    │
└─────────────────────────────────┼───────────────────────────────────────┘
                                  │  (artifact registry / GH release)
┌─────────────────────────────────┼───────────────────────────────────────┐
│  ONLINE                         ▼                                       │
│                  ┌──────────────────────────────────────────┐          │
│   Browser  ◀────▶│  FastAPI  (service/app/main.py)          │          │
│   (web/ UI)      │   /healthz  /version                     │          │
│                  │   /preprocess  → tiles + previews        │          │
│                  │   /predict     → grade + distribution    │          │
│                  │   ONNXRuntime CPU · in-process, no queue │          │
│                  └──────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────────────────┘
```

**Serving pattern:** *train by batch, predict on the fly, serve via REST*
— pattern 1 in the original study's taxonomy, and still the right call. It
decouples the model from the UI, so the interface can be redesigned or replaced
without touching inference, and a second client (a PACS plug-in, a mobile app)
can be added later against the same contract.

Explicitly **rejected**: shared-DB batch prediction (latency unacceptable for
interactive second-opinion use) and streaming (operationally absurd for a
one-slide-at-a-time workload).

---

## 3. Data flow, in detail

### 3.1 Tiling

PANDA slides are mostly white space — the tissue strip occupies perhaps 5–15% of
the canvas. Feeding the raw slide to a CNN spends nearly all its capacity on
background. The original study's key empirical finding (Table 4.1.1: tiles beat
raw data, 75.8% vs 73.4% test) is correct and we keep it.

```
level-1 image (≈ 5000 × 5000)
        │  pad to a multiple of 256
        ▼
   grid of 256×256 tiles
        │  score each tile by tissue mass:  255*3*256² − Σ pixel
        ▼
   keep top N=36 tiles by score
        │  arrange 6×6
        ▼
   montage 1536 × 1536 → resize 512 × 512 → model input
```

**Why a montage rather than a bag?** Two candidate designs:

| | Tile-montage (chosen) | Attention-MIL over tiles |
|---|---|---|
| Model sees | one 6×6 composite image | N independent tile embeddings, pooled by learned attention |
| Params | 1× backbone | 1× backbone + attention head |
| Inference cost | 1 forward pass | N forward passes (or 1 batched) |
| Per-tile attribution | via Grad-CAM on the composite grid | native, from attention weights |
| PANDA leaderboard evidence | used by several top-10 solutions | used by the winner |
| Latency @ CPU | ~1.2 s | ~4–6 s |

Montage wins under constraint N1. We lose native attention attribution but
recover a usable substitute: Grad-CAM over the composite decomposes cleanly back
to tile coordinates because the grid is axis-aligned.

### 3.2 Colour handling — a correction

The original pipeline converted tiles to **grayscale** before the Gaussian
filter. This is a mistake worth being explicit about: Gleason grading is a
judgement about *glandular architecture stained with haematoxylin and eosin*.
Nuclear basophilia (H, blue-purple) versus cytoplasmic eosinophilia (E, pink) is
the signal that separates a gland lumen from stroma from a cribriform sheet.
Grayscale collapses two chemically distinct channels onto one intensity axis and
destroys that contrast.

ProGENET keeps RGB and instead applies **Macenko stain normalisation**, which
addresses the actual problem grayscale was reaching for — scanner and protocol
variation between Radboud and Karolinska — without discarding the stain
information.

The Gaussian filter is retained but demoted: the original ablation (Table 4.1.2b)
found σ = 4 optimal with performance collapsing by σ = 10, which is the
signature of a mild denoiser helping slightly, not of a load-bearing component.
It is applied at σ = 1.0 as light denoising, configurable, defaulting to off for
the final model.

### 3.3 Label mapping

PANDA gives `gleason_score` (e.g. `"3+4"`) and `isup_grade` (0–5). These are not
independent — ISUP is a deterministic function of the Gleason pair:

| Gleason | 0+0 / negative | 3+3 | 3+4 | 4+3 | 4+4, 3+5, 5+3 | 4+5, 5+4, 5+5 |
|---|---|---|---|---|---|---|
| **ISUP** | 0 | 1 | 2 | 3 | 4 | 5 |

We train on **ISUP** (6 ordinal classes) and derive the reported Gleason pattern
from the predicted ISUP via the inverse of this table. Training on the 10-way
Gleason-pair label, as the original did ("discrete numbers ranging from 0–9"),
throws away the ordering and creates classes that differ only by which pattern is
primary — a distinction the model cannot make from a whole-slide label anyway.

### 3.4 Ordinal head

ISUP grade is ordinal: confusing 4 with 5 is a minor error; confusing 0 with 5
is a catastrophe. Softmax cross-entropy treats both identically. We use a
**cumulative-link (ordinal-BCE) head**:

```
target for ISUP grade g  →  [1]*g + [0]*(5-g)      # 5 binary units
                            ISUP 0 → [0,0,0,0,0]
                            ISUP 3 → [1,1,1,0,0]
loss                     →  BCEWithLogits over the 5 units
prediction               →  ĝ = Σ 1[σ(logit_k) > τ_k]
```

The thresholds `τ` are then optimised post-hoc directly against QWK on the
validation fold (Nelder–Mead over 5 scalars) — a standard PANDA trick worth
0.01–0.03 QWK for free.

*Aside:* this retroactively justifies the original writeup's otherwise puzzling
choice of `binary_crossentropy` for a "multi-class model". BCE over cumulative
ordinal units is the principled version of that instinct.

### 3.5 Validation split

`StratifiedGroupKFold(n_splits=5)` on `isup_grade`, grouped by `image_id`, with
`data_provider` tracked so per-provider QWK is reportable. Additionally, one
**shift probe**: train on Radboud only, evaluate on Karolinska only. That number,
not the pooled QWK, is the honest estimate of what happens when the model meets a
new lab (risk R2).

---

## 4. API contract

```http
POST /predict
Content-Type: multipart/form-data
  file: <biopsy image, jpg/png/tiff, ≤ 20 MB>
  tiles: 36            # optional, 16|36|64
  explain: true        # optional, returns Grad-CAM overlay
```

```jsonc
200 OK
{
  "request_id": "b31f…",
  "model": { "name": "progenet-b0-ordinal", "version": "1.0.0", "qwk_val": 0.842 },
  "prediction": {
    "isup_grade": 2,
    "gleason_score": "3+4",
    "risk_band": "intermediate-favourable",
    "confidence": 0.71
  },
  "distribution": {                    // calibrated, sums to 1
    "0": 0.02, "1": 0.14, "2": 0.71, "3": 0.09, "4": 0.03, "5": 0.01
  },
  "ordinal_logits": [4.1, 1.9, -1.2, -3.0, -4.4],
  "tiles": { "requested": 36, "tissue_bearing": 31, "coverage": 0.86 },
  "attribution": { "grid": [6,6], "weights": [[0.01, …], …] },   // if explain
  "flags": ["LOW_TISSUE_COVERAGE"],    // OOD / quality warnings
  "latency_ms": 1840,
  "disclaimer": "Research use only. Not a medical device. Not for clinical decision-making."
}
```

```http
POST /preprocess   → returns the tile montage, stain-normalised and
                     Gaussian-filtered previews as base64 PNGs.
                     Used by the UI to show the pipeline, not just the answer.
GET  /healthz      → { "status": "ok", "model_loaded": true }
GET  /version      → build SHA, model version, preprocessing config hash
```

**Errors**

| Code | Condition |
|---|---|
| 413 | File > 20 MB |
| 415 | Not a decodable image |
| 422 | Tissue coverage < 5% — refuse rather than guess |
| 503 | Model artifact not loaded |

**Design notes.** No auth in v1 — there is no PHI and no per-user state; adding
OAuth before there are users is premature. Uploads are held in memory and
discarded after the response; nothing is written to disk. Rate limiting is one
token bucket per IP, 30/min, enforced at the reverse proxy rather than in app
code.

---

## 5. Scale and reliability

**Load estimate.** Target users are pathology labs. A busy uropathology service
reads perhaps 40 prostate biopsies a day. Ten such labs = 400 requests/day,
concentrated in a 6-hour window → ~1.1 rps mean, maybe 5 rps peak. At 2.5 s warm
latency and 2 workers, a single 2-vCPU container handles it with a factor of 3
headroom.

**This is a small system, and it should be built like one.** No queue, no
autoscaler, no service mesh. One container behind Cloud Run / Render / a Hugging
Face Space, scale-to-zero, cold start absorbed by the ONNX artifact being small
enough (< 250 MB, N3) to load in ~3 s.

| Growth trigger | What changes |
|---|---|
| > 20 rps sustained | Move to 4 replicas behind a load balancer. Still no queue. |
| Whole-slide `.tiff` uploads (500 MB+) | *Now* add a job queue — tiling a real WSI is 30–90 s and cannot ride a request. Async `202 + /jobs/{id}`. |
| Multi-tenant / hospital deployment | Auth, audit log to append-only storage, per-tenant model pinning. |
| Model ensembling for accuracy | Only if the latency budget is formally renegotiated. |

**Monitoring.** Four signals, nothing more: p95 latency, error rate, prediction
distribution drift (a sudden collapse toward one grade means something upstream
broke), and `LOW_TISSUE_COVERAGE` flag rate (a proxy for users sending the wrong
kind of image).

---

## 6. Trade-off ledger

| Decision | Chosen | Rejected | Cost we accept |
|---|---|---|---|
| Tile aggregation | 6×6 montage | Attention-MIL | ~0.01–0.02 QWK, and attribution becomes indirect |
| Backbone | EfficientNet-B0/B3 | EfficientNet-B7 (paper's best) | Some accuracy; B7 at 66 M params breaks N1 and N3 |
| Colour | RGB + Macenko | Grayscale (paper) | Slightly more preprocessing cost |
| Head | Ordinal cumulative-link | Softmax CE | Marginally more code; large QWK gain |
| Serving | REST, sync, in-process | Queue + workers | Cannot accept raw WSI uploads in v1 |
| Preprocessing orchestration | Nextflow | A bash script | Nextflow is a dependency; bought back in resumability + provenance |
| Web UI | Static SPA against the API | Streamlit (paper) | Must write our own front-end; gained: no Python process per viewer, deployable anywhere, far better UX |
| Auth | None in v1 | OAuth/API keys | Must add before any real deployment with uploads worth protecting |

---

## 7. What I would revisit first

1. **The montage decision**, if a GPU ever becomes part of the serving budget. Attention-MIL is the better model; it is only losing on CPU latency.
2. **The single-fold training budget.** A 5-fold ensemble is worth ~0.02 QWK and costs 5× the Kaggle sessions — cheap in money, expensive in wall-clock. Worth doing once the pipeline is stable.
3. **Refusing rather than guessing.** The 422-on-low-coverage rule is currently a fixed 5% threshold. It should be learned — an explicit OOD detector on the tile embedding distribution would be more honest than a pixel heuristic.
4. **Calibration.** The reported `distribution` is softmax-over-ordinal-logits, which is not calibrated. Temperature scaling on the validation fold is an afternoon's work and makes the confidence number mean something.

---

## Related

- [ADR-001](adr/ADR-001-tile-aggregation.md) — tile montage vs. attention-MIL
- [ADR-002](adr/ADR-002-ordinal-head.md) — ordinal head vs. softmax
- [ADR-003](adr/ADR-003-serving-pattern.md) — synchronous REST vs. queue
- [ADR-004](adr/ADR-004-stain-normalisation.md) — RGB + Macenko vs. grayscale
