# ProGENET — Runbook

Operating the preprocessing pipeline and the inference service. Written for the
person on call at 2 a.m., which in a two-person research project is you.

---

## 1 · Health checks

```bash
curl -s localhost:8080/healthz    # {"status":"ok","model_loaded":true}
curl -s localhost:8080/version    # model name, version, QWK, preprocessing hash
```

`preprocessing_hash` is the one to record in any bug report. Two services with
the same model version but different preprocessing hashes will disagree, and the
hash is the only thing that reveals it.

---

## 2 · Symptom → cause

### `/predict` returns 503

The service is up and the model is not loaded. Check `/version`: a null `model`
confirms it.

```bash
ls service/artifacts/          # must hold exactly one *.onnx and model_meta.json
docker logs <container> | grep -i "no artifacts"
```

The service deliberately starts without artifacts so a deploy does not crash-loop
on a missing file. Copy the artifacts in and restart.

### `/predict` returns 422 `insufficient_tissue`

Working as designed — under 5% of the upload is tissue, and ProGENET refuses
rather than guessing. Almost always one of:

- a photograph of a screen, or a non-histology image
- a slide thumbnail so small that tiling padded it with white
- an inverted/negative scan, where the tissue scorer reads background as ink

Check the reported `coverage` in the error body. Below 0.01 means it is not
histology at all; 0.02–0.05 usually means a too-small crop.

### Latency above the 8 s budget

Order of suspicion:

1. **Cold start.** First request after scale-to-zero includes the ONNX load
   (~3–5 s). Check whether the previous request was minutes ago.
2. **Thread contention.** `OMP_NUM_THREADS` and `intra_op_num_threads` must both
   be 2 on a 2-vCPU box. Unset, ONNXRuntime spawns a thread per core it *thinks*
   it has, which on a cgroup-limited container is the host's core count, and the
   oversubscription costs more than it buys.
3. **A large upload.** A 20 MB PNG decodes slowly. The tiling itself is
   O(pixels); a 10,000 px image costs several seconds before the model runs.
4. **Backbone.** If someone swapped in EfficientNetB7 (66 M params), the budget
   is simply gone. Check `/version` → `model`.

### Predictions collapse toward one grade

The drift signal, and the most serious failure mode because nothing errors.

```bash
# distribution of the last 500 predictions
docker logs <container> | grep "predict" | grep -o "ISUP ." | sort | uniq -c
```

Expect something roughly resembling PANDA's grade mix. All-one-grade means:

- **Wrong thresholds.** `model_meta.json` thresholds got replaced or defaulted to
  `[0.5]*5` from a different training run. Compare against the notebook output.
- **Preprocessing skew.** The stain reference in `model_meta.json` differs from
  the one used at training. Compare `preprocessing_hash` against the notebook's.
- **Genuinely skewed input.** Someone is batch-uploading one case type.

### `NON_MONOTONE_ORDINAL` flag appearing often

The cumulative units are coming back out of order — unit 3 firing harder than
unit 2. Occasional instances are normal (ADR-002: monotonicity is encouraged by
the target encoding, not enforced by the architecture). Above ~5% of requests it
means the head is undertrained; retrain for more epochs before trusting the
distribution.

---

## 3 · Pipeline failures

### `nextflow run` fails immediately

```bash
nextflow run pipeline/main.nf -profile test,docker --outdir /tmp/t
```

If the test profile fails, the environment is the problem, not your data.
Nextflow ≥ 23.04 and Java ≥ 11 are required:

```bash
nextflow -version && java -version
```

### `TILE_EXTRACT` OOM (exit 137)

A level-1 PANDA slide can decompress to several GB. The process carries
`process_high_memory` and retries with doubled memory twice. If it still dies:

```bash
nextflow run ... --level 2      # 16x downsample instead of 4x
```

Note that dropping to level 2 changes the input distribution — it is a different
preprocessing config, so retrain rather than mixing shards across levels.

### "Slide not found, skipping"

Expected for a handful of slides. PANDA ships known-corrupt files and the
pipeline warns rather than failing a six-hour job over one bad file. If the count
is in the hundreds, `--slide_dir` is wrong.

### Resuming

```bash
nextflow run pipeline/main.nf -profile docker ... -resume
```

Completed tasks are cached by input hash. Changing any tiling parameter
invalidates the cache for every slide, correctly — the shards would otherwise be
a mix of two preprocessing configs.

---

## 4 · Training failures

### Kaggle session times out mid-training

Checkpoints are written to `/kaggle/working/progenet_<backbone>_fold<n>.pt`
on every validation improvement. They survive the timeout. Restart the notebook,
skip to the training cell, and load the checkpoint before continuing.

### QWK stuck near zero

Check the target encoding first, before anything else. An off-by-one in the
cumulative encoding (`y_ord[:g]` vs `y_ord[:g+1]`) produces a model that trains
smoothly, shows a falling loss, and scores at chance — the exact signature the
2021 study's logs show. Print a few `(isup_grade, y_ord)` pairs and check by eye:

```
ISUP 0 → [0,0,0,0,0]     ISUP 3 → [1,1,1,0,0]
ISUP 1 → [1,0,0,0,0]     ISUP 5 → [1,1,1,1,1]
```

### Out of GPU memory

`batch_size=4, accum_steps=4` keeps the effective batch at 16. Failing that,
`img_size=384`.

---

## 5 · Deploying a new model

```bash
# 1 · stage
cp progenet_*.onnx model_meta.json service/artifacts/
pytest service/tests -q                       # parity must pass

# 2 · verify locally before it reaches anyone
docker build -t progenet:new service/ && docker run -d -p 8081:8080 progenet:new
curl -s localhost:8081/version | jq '.qwk_val, .preprocessing_hash'
for f in fixtures/*.png; do curl -s -F file=@$f localhost:8081/predict | jq -c '.prediction'; done

# 3 · ship
docker tag progenet:new progenet:$(date +%Y%m%d) && docker push ...
```

**Before shipping, confirm three things.** The `qwk_val` in `/version` matches
what the notebook reported. The `preprocessing_hash` changed if and only if you
intended to change preprocessing. The fixture predictions are sane — a set of
known-grade images that should come back at their known grades, or close.

**Rollback** is redeploying the previous image tag. The service is stateless;
there is nothing to migrate and nothing to undo.

---

## 6 · What to watch

Four signals, nothing more:

| Signal | Healthy | Alarming |
|---|---|---|
| p95 latency | < 4 s | > 8 s sustained |
| 5xx rate | ~0 | anything sustained |
| Prediction distribution | resembles PANDA's grade mix | collapse toward one grade |
| `LOW_TISSUE_COVERAGE` rate | < 10% | > 30% — users are sending the wrong thing |

The third is the one that catches a silent preprocessing regression, and it is
the one no off-the-shelf monitor will give you. Log it.

---

## 7 · Things that are not incidents

- **Cold start on the first request of the day.** Scale-to-zero. Set a
  min-instance if it becomes annoying.
- **A 422 on a non-histology upload.** The refusal is the feature.
- **Cross-provider QWK below the pooled number.** Expected, measured, and
  documented in [01-problem-framing.md §7](01-problem-framing.md). It is a
  finding, not a fault.
