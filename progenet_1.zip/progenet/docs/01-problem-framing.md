# ProGENET — Problem Framing

**Pro**state **G**leason **E**valuation **NET**work

Applied framework: Fischbach & Walsh, *Problem choice and decision trees in science and engineering*, Cell 187 (2024).

---

## 1. The kernel

Prostate biopsy grading is the single strongest prognostic input into treatment
choice, and it is produced by a human eye applying a 1966 pattern taxonomy to a
glass slide. Inter-observer agreement between general pathologists on ISUP grade
sits around κ = 0.55–0.65; agreement between a general pathologist and a
uropathology subspecialist is worse still. The consequence is not academic: a
2+2 read where a subspecialist would say 4+3 is the difference between active
surveillance and radical prostatectomy.

**ProGENET's kernel:** grade the *whole biopsy*, not a hand-picked field, by
learning an ordinal grade directly from tiled whole-slide images — and expose it
as a second-opinion service that reports its own uncertainty rather than a bare
number.

This is a re-execution of the 2021 University of Lagos study (Bamigbade &
Abubakar-Sidiq, *Gleason Score Prediction for the Severity of Prostate
Metastasis Using Machine Learning*), rebuilt with the design corrections listed
in §5.

---

## 2. Position on the two axes

| Axis | Assessment |
|---|---|
| **Likelihood of success** | **High.** The PANDA challenge (Bulten et al., *Nat Med* 2022) established that this is a solvable supervised problem with 10,616 labelled slides. Public leaderboard QWK reached 0.94; the top solutions are published. We are not asking whether it can be done — we are asking whether it can be done reproducibly, and served. |
| **Impact if successful** | **Moderate-to-high, and bounded by deployment, not accuracy.** A model at κ = 0.90 that nobody can run in a Lagos or Kano pathology lab has near-zero clinical impact. A model at κ = 0.85 that runs behind a URL on commodity hardware has real impact in exactly the low-resource settings the original study targeted. |

The interesting move is therefore **rightward on deployability**, not upward on
accuracy. That reframing drives every architectural decision in
[02-system-design.md](02-system-design.md).

---

## 3. Risk assessment matrix

| # | Risk | Likelihood (1–5) | Severity (1–5) | Mitigation | Kill criterion |
|---|---|---|---|---|---|
| R1 | **Label noise.** PANDA's Karolinska labels come from a single pathologist; Radboud labels are semi-automatic from immunohistochemistry-guided annotation. Noisy ceiling. | 5 | 3 | Train provider-aware; report per-provider QWK; use ordinal loss which is tolerant to ±1 label slip. | None — this is a floor to be characterised, not escaped. |
| R2 | **Distribution shift.** A model trained on Radboud + Karolinska scanners degrades on a third scanner/stain protocol. | 4 | 5 | Macenko stain normalisation at inference; hold out one provider entirely as a shift probe; surface an OOD flag in the API. | If cross-provider QWK drops below 0.60, the deployment claim is void and the project becomes a domain-adaptation project. |
| R3 | **Tiling discards the diagnostic region.** Naive top-N tile selection by tissue density can miss a small high-grade focus. | 3 | 5 | Select tiles by *saturation-weighted* tissue score, not raw density; use 36 tiles (paper's number) as a floor, ablate at 16/36/64. | — |
| R4 | **Compute.** Full-resolution WSIs are 10–100k px per side; the dataset is ~400 GB. | 4 | 3 | Tile at level 1 (4× downsample) as PANDA convention; preprocessing runs as a Nextflow pipeline that is resumable and parallel; training runs on Kaggle's free P100/T4 within the 9 h session limit. | — |
| R5 | **Clinical mis-use.** A pathologist trusts the output on a case where the model is out of its depth. | 3 | 5 | The UI never shows a bare grade: it shows grade + confidence distribution + per-tile attribution + an explicit "research use only" banner. Refuse to emit a grade below a confidence floor. | — |
| R6 | **Nobody uses it.** | 4 | 4 | Deployment is a first-class objective (Objective 3), not an appendix. Web UI ships in the same repo as the model. | — |

**Aggregate:** no "multiple miracles" required. R2 is the one risk that is both
likely and severe, and it is the risk the original study did not measure at all.
Making R2 measurable is ProGENET's main scientific contribution over the 2021
work.

---

## 4. Optimization function

What are we actually maximising?

```
maximise    QWK on a held-out, provider-stratified split
subject to  end-to-end inference latency  < 8 s on 2 vCPU / 4 GB RAM
            model artifact size           < 250 MB
            preprocessing reproducible    from a single `nextflow run`
            every prediction carries      a calibrated confidence distribution
```

Note what is *not* in the objective: top-1 accuracy. The original study reported
85.2% / 84.8% train/test accuracy. Accuracy is the wrong metric for an ordinal
5-class problem with an imbalanced grade distribution — a model that always
predicts ISUP 1 scores respectably on accuracy and is clinically useless.
Quadratic weighted kappa penalises being wrong *by how far* you are wrong, which
is exactly the clinical cost structure. The original writeup computed QWK during
training (its logs show `QWK_score: 0.036`, i.e. essentially chance) while
reporting accuracy in its results tables — the two numbers tell contradictory
stories and QWK is the one to believe.

**This is the single most important correction ProGENET makes.**

---

## 5. Fixed parameter (and what floats)

Fix **one** meaningful constraint; let everything else float.

> **Fixed:** the model must run inference on CPU-only commodity hardware in
> under 8 seconds, from raw uploaded biopsy image to rendered report.

Everything downstream follows from that one commitment:

| Floats | Because |
|---|---|
| Backbone (B0 / B3 / B7 / ResNet) | Chosen empirically under the latency budget — B7 at 66 M params is likely out. |
| Tile count N | Ablated at 16 / 36 / 64. |
| Loss formulation | Ordinal-BCE vs. softmax-CE vs. regression+thresholds. |
| Serving framework | FastAPI, Streamlit, or static+ONNX — whichever meets the budget. |

Had we instead fixed "must beat 0.90 QWK", we would have been pushed toward
ensembles of large backbones, and the deployability that is the entire point
would have been the thing that floated away.

---

## 6. Decision tree

```
                        Can we reproduce PANDA-level QWK ≥ 0.80
                        on a single-fold, single-backbone budget?
                                     │
                ┌────────────────────┴────────────────────┐
               YES                                        NO
                │                                          │
     Does it hold cross-provider                 Is the gap from capacity
     (train Radboud → test Karolinska)?          or from preprocessing?
                │                                          │
      ┌─────────┴─────────┐                    ┌───────────┴──────────┐
     YES                 NO                 capacity              preprocessing
      │                   │                    │                       │
  ── SHIP ──      Domain adaptation      Scale backbone,        Fix tiling /
  Serve it,       becomes the project:   accept latency          stain norm
  measure in      stain norm, adversarial  renegotiation       (cheap — do first)
  the wild        provider head
```

**Altitude discipline:** the two branch points above are the only moments to
stop and think strategically. Between them, execute — do not re-litigate the
architecture every time a validation number wobbles.

---

## 7. Adversity playbook

| If this happens | Do not | Do |
|---|---|---|
| QWK plateaus at ~0.70 | Add more backbones | Check the label mapping first. Ordinal targets are easy to get subtly wrong (off-by-one on ISUP 0 vs. 1). |
| Kaggle session times out mid-training | Restart from scratch | Checkpoint every epoch to `/kaggle/working`; resume is built into the notebook. |
| The model is confidently wrong on a benign slide | Patch with a threshold | Look at tile attributions. Benign false-positives usually trace to tiles dominated by inflammation or artefact — a tissue-filter problem, not a model problem. |
| Cross-provider collapse (R2 fires) | Quietly train on both and report the pooled number | Report it. The negative result — "single-institution histology models do not transfer" — is the more useful publication, and it is what the field needs from low-resource-setting deployments. |

---

## 8. What "done" looks like

1. `nextflow run pipeline/main.nf` turns raw PANDA WSIs into training-ready tile shards on any machine with Docker.
2. The Kaggle notebook trains to QWK ≥ 0.80 on a single fold within one session.
3. The FastAPI service loads the exported weights and answers `POST /predict` in under 8 s on 2 vCPU.
4. A pathologist can open a URL, drag a biopsy image onto it, and read a grade with its confidence distribution — without installing anything.

Items 1, 3 and 4 are what the 2021 study could not claim. Item 2 is what it
claimed but, on its own QWK numbers, did not achieve.
