# ProGENET

**Pro**state **G**leason **E**valuation **NET**work — ordinal ISUP grading of
prostate biopsy whole-slide images, from raw PANDA slides through to a deployed
second-opinion interface.

> **Research use only. Not a medical device. Not for clinical decision-making.**

---

## What this is

A rebuild of *Gleason Score Prediction for the Severity of Prostate Metastasis
Using Machine Learning* (Bamigbade & Abubakar-Sidiq, Department of Systems
Engineering, University of Lagos, 2021) on the same
[PANDA challenge](https://www.kaggle.com/c/prostate-cancer-grade-assessment)
dataset — 10,616 slides from Radboud UMC and the Karolinska Institute.

Four things changed, each argued in an ADR:

| | 2021 | ProGENET | Why |
|---|---|---|---|
| Tile handling | 36 tiles → whole slide resized | 36 tiles → 6×6 montage ranked by ink | [ADR-001](docs/adr/ADR-001-tile-aggregation.md) |
| Colour | grayscale + Gaussian σ=4 | RGB + Macenko stain normalisation | [ADR-004](docs/adr/ADR-004-stain-normalisation.md) |
| Target | 10-way Gleason pair, softmax | 6-way ISUP, cumulative-link ordinal | [ADR-002](docs/adr/ADR-002-ordinal-head.md) |
| Metric | accuracy (85.2% / 84.8%) | quadratic weighted kappa | see below |

That last row is the one that matters. The original reported 84.8% test accuracy
for EfficientNetB7 while its own training logs show QWK oscillating around 0.04 —
chance agreement. Both numbers were honestly measured; they measure different
things, and only kappa notices a model that has learned the marginal grade
distribution instead of the morphology. **ProGENET optimises kappa.**

---

## Layout

```
progenet/
├── docs/
│   ├── 01-problem-framing.md      risk matrix, optimisation function, decision tree
│   ├── 02-system-design.md        requirements, architecture, API contract, scale
│   ├── 03-runbook.md              operating the pipeline and the service
│   └── adr/                       ADR-001 … ADR-004
├── pipeline/                      Nextflow DSL2 — PANDA WSI → training shards
│   ├── main.nf  nextflow.config
│   ├── modules/local/             TILE_EXTRACT · STAIN_NORMALISE · PACK_SHARDS · QC_REPORT
│   ├── bin/                       tile_wsi.py · preprocess_tiles.py · pack_shards.py · qc_report.py
│   └── assets/                    samplesheet contract + test sheet
├── notebooks/
│   ├── progenet-panda-training.ipynb   the Kaggle notebook — train here
│   └── build_notebook.py               regenerates the .ipynb from source
├── service/                       FastAPI + ONNXRuntime inference
│   ├── app/                       main.py · inference.py · preprocessing.py
│   ├── artifacts/                 ← drop progenet_*.onnx + model_meta.json here
│   ├── tests/test_parity.py       asserts pipeline ≡ service preprocessing
│   └── Dockerfile  requirements.txt
└── web/index.html                 the console — self-contained, no build step
```

---

## Quick start

### 1 · Preprocess (optional — the notebook can tile on the fly)

```bash
nextflow run pipeline/main.nf -profile docker \
    --input     /data/panda/train.csv \
    --slide_dir /data/panda/train_images \
    --outdir    results
```

Produces `results/shards/*.npy` + parquet manifests and a QC report at
`results/qc/progenet_qc.html`. Check the grade distribution and provider balance
there before spending a GPU session. Smoke test first:

```bash
nextflow run pipeline/main.nf -profile test,docker --outdir test_out
```

### 2 · Train

Upload `notebooks/progenet-panda-training.ipynb` to Kaggle, add the
*Prostate cANcer graDe Assessment (PANDA) Challenge* dataset, set
**Accelerator: GPU** and **Internet: On**, then *Save & Run All*.

Roughly 35 min/epoch on a P100 at 512 px / 36 tiles; one fold of 10 epochs fits
the 9-hour session. Outputs `progenet_<backbone>.onnx` and `model_meta.json`.

### 3 · Serve

```bash
cp ~/Downloads/progenet_*.onnx ~/Downloads/model_meta.json service/artifacts/
docker build -t progenet service/
docker run -p 8080:8080 progenet

curl -F file=@biopsy.png http://localhost:8080/predict | jq
```

Without artifacts the service still starts; `/predict` answers `503` and
`/healthz` reports `model_loaded: false`.

### 4 · Open the console

```bash
python3 -m http.server -d web 5173   # then http://localhost:5173
```

Enter `http://localhost:8080` in the *Connect a trained model* panel. Run from
here rather than the published page — a hosted artifact's sandbox blocks
outbound requests.

---

## Model card, abbreviated

| | |
|---|---|
| **Task** | 6-class ordinal ISUP grade (0–5) from a prostate biopsy image |
| **Training data** | PANDA — 10,616 H&E WSIs, Radboud UMC + Karolinska Institute |
| **Input** | 36 tissue-ranked 256 px tiles, 6×6 montage, resized 512², Macenko-normalised, ImageNet statistics |
| **Architecture** | ImageNet backbone → GeM pooling → 5-unit cumulative-link head |
| **Loss** | `BCEWithLogits` over cumulative ordinal units |
| **Metric** | Quadratic weighted kappa; thresholds fit post-hoc by Nelder–Mead |
| **Validation** | 5-fold stratified on (grade × provider), one fold trained per session |
| **Shift probe** | Train Radboud → test Karolinska; below 0.60 QWK is a kill criterion |
| **Not evaluated on** | Any third institution, any non-H&E stain, any scanner outside the two above, any tissue other than prostate needle biopsy |
| **Known limitations** | Slide-level labels only; Karolinska labels are one pathologist's read; raw `.tiff` WSI upload is out of scope in v1 (ADR-003) |
| **Intended use** | Research and second-opinion prototyping |
| **Out of scope** | Primary diagnosis, treatment decisions, screening, any use where a person is affected by the output |

---

## Tests

```bash
pip install pytest numpy pillow
pytest service/tests -q
```

17 tests covering tiling determinism, tissue ranking, white-padding behaviour,
Macenko graceful degradation, colour-variance reduction, ordinal decoding, and
distribution validity — plus the parity assertion that the pipeline's
preprocessing and the service's produce byte-identical montages.

---

## Credits

Original study: Opeyemi Bamigbade (160407516) and Halimah Abubakar-Sidiq
(150407048), supervised by Dr. O. P. Popoola, Department of Systems Engineering,
University of Lagos, October 2021.

Dataset: Bulten et al., *Artificial intelligence for diagnosis and Gleason
grading of prostate cancer: the PANDA challenge*, Nature Medicine 28 (2022).

Stain normalisation: Macenko et al., *A method for normalizing histology slides
for quantitative analysis*, ISBI (2009).
